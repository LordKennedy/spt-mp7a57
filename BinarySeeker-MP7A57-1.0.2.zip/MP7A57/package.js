const { MP7A57 } = require("./src/MP7A57.js");

module.exports.mod = new MP7A57();