# MP7A57  
5.7x28mm variant of the MP7 for SPTarkov  
Follows ATLAS's item template from Senko's Pub.  
Use the Config.json to change the listing price.  